/** @file Cloud_Resource_Billing_System_Standard.c
*
* @brief
C program to add customer details and to calculate
the total bill for cloud resource usage in minutes, then save the
updated data regarding customer details to a new file.
*
* @par
* COPYRIGHT NOTICE: (c) 2024 Murugesan. All rights reserved.
*/

#include "cloud_resource_billing_all_functions_updated_secure.h"

// typedef int uint32_t;
// typedef char uchar1_t;
// typedef float float32_t;

/**
 * @brief Trims leading and trailing whitespace from a string.
 *
 * This function removes all leading and trailing whitespace characters from
 * the provided string. It modifies the string in place.
 *
 * @param str A pointer to the string to be trimmed.
 * @pre The string pointed to by str must be a valid null-terminated C string.
 * @post The string is modified in place to remove leading & trailing whitespace.
 */
void trim_whitespace(uchar1_t *str)
{
    uchar1_t *start = str;
    uchar1_t *end;

    // Trim leading spaces
    while (isspace((unsigned char)*start)) // Properly cast to `unsigned char` to avoid undefined behavior
    {
        start++;
    }

    // If all spaces, return an empty string
    if (*start == 0)
    {
        *str = '\0'; // Set the first character to null if the string is empty after trimming
        return;
    }

    // Find the end of the string (after trimming trailing spaces)
    end = start + strnlen(start,sizeof(start)) - 1;
    while (end > start && isspace((unsigned char)*end))
    {
        end--;
    }

    // Null-terminate the string at the end of the trimmed portion
    *(end + 1) = '\0';

    // Move the trimmed string to the original pointer location
    memmove(str, start, end - start + 2); // Use memmove to handle overlapping memory areas safely
}

/**
 * @brief Generates a random floating-point number within a specified range.
 *
 * This function generates a pseudo-random floating-point number between the
 * specified minimum and maximum values. The function uses the `rand()` function
 * to generate a random integer, which is then scaled to a floating-point number
 * in the range [min, max]. The result is uniformly distributed across the range.
 *
 * @param min The minimum value of the range (inclusive).
 * @param max The maximum value of the range (exclusive).
 * @return A random floating-point number between min and max.
 * @pre The `rand()` function should be seeded using `srand()` before calling this function.
 * @post The generated number is a pseudo-random floating-point value.
 */
float32_t generate_random_double(float32_t min, float32_t max)
{
    if (min >= max)
    {
        fprintf(stderr, "Error: min must be less than max.\n");
        return 0.0f; // Return a default value in case of invalid input
    }

    // Generate a random integer and scale it to the desired range
    float32_t scale = rand() / (float32_t)RAND_MAX;
    return min + scale * (max - min); // Scale to [min, max]
}

/***  end of file  ***/
