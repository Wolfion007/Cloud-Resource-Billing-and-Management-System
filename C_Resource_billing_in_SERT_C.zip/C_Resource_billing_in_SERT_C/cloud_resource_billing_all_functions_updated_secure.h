#ifndef CLOUD_RESOURCE_BILLING_ALL_FUNCTIONS_UPDATED_SECURE_H
#define CLOUD_RESOURCE_BILLING_ALL_FUNCTIONS_UPDATED_SECURE_H

#include <stdio.h> // For FILE type and standard I/O functions
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

// Define any required data structures, constants, or typedefs
typedef int uint32_t;
typedef char uchar1_t;
typedef float float32_t;

#define MAX_ID_LENGTH 5    // Total length of the user_id
#define MAX_NAME_LENGTH 21 // Max length for customer names

typedef struct
{
    uchar1_t name[MAX_NAME_LENGTH];
    uchar1_t user_id[MAX_ID_LENGTH];
    float32_t usage;
    float32_t other_computing_resources;
    float32_t unit_storage;
    float32_t unit_database;
    float32_t total_bill;
} customer_data;

// Function Prototypes
void trim_whitespace(uchar1_t *str);
float32_t generate_random_double(float32_t min, float32_t max);

// Function prototypes
void add_record(void);
void initialize_customers(void);
void cleanup_customers(void);
void first_and_recent_user(FILE *h_ffptr);
void view_records(void);
void modify_records(uchar1_t user_id[]);
void view_payment(uchar1_t user_id[]);
void search_records(uchar1_t user_id[]);
void delete_records(uchar1_t user_id[]);
void term_customer_reward(customer_data customers[], uint32_t count);

#endif // CLOUD_RESOURCE_BILLING_ALL_FUNCTIONS_UPDATED_SECURE_H
