#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "cloudresourcebillingfunctionsupdated.h"

#define MAX_CUSTOMERS 100
#define MAX_MONTHS 10


int main()
{
    int choice;
    char userId[4];

    while (1)
    {
        printf("\n--- Customer Records Menu ---\n");
        printf("1. Add Record\n");
        printf("2. View Records\n");
        printf("3. Modify Record\n");
        printf("4. View Payment\n");
        printf("5. Search Record\n");
        printf("6. Delete Record\n");
        printf("7. Finding First and Recent Cutomer \n");
        printf("8. Rewarding the user with Highest Usage \n");
        printf("9. Erasing all customer data from the database \n");
        printf("10. Exit \n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            addrecord();
            printf("--------------------------------------------------------------\n");
            break;
        case 2:
            viewrecords();
            printf("--------------------------------------------------------------\n");
            break;
        case 3:
            printf("\nEnter userId(3 characters) to modify record: ");
            scanf("%s", userId);
            modifyRecord(userId);
            char filename[] = "modifiedcloudcustomerdata.txt";
            FILE *sfile=fopen(filename, "r");
            openFile(filename);
            fclose(sfile);
            printf("--------------------------------------------------------------\n");
            break;
        case 4:
            printf("\nEnter userId to view payment: ");
            scanf("%s", userId);
            viewPayment(userId);
            printf("--------------------------------------------------------------\n");
            break;
        case 5:
            printf("\nEnter userId to search record: ");
            scanf("%s", userId);
            searchRecord(userId);
            printf("--------------------------------------------------------------\n");
            break;
        case 6:
            printf("\nEnter userId to delete record: ");
            scanf("%s", userId);
            deleteRecord(userId);
            printf("--------------------------------------------------------------\n");
            break;
        case 7:
            FILE *ffptr = fopen("cloudcustomerdata.txt", "r");
                if (ffptr) 
                {
                    printf("\nThe First and the Most Recent user is:\n");
                    printf("--------------------------------------------------------------\n");
                    firstandlastuser(ffptr);
                    fclose(ffptr);
                } else {
                    perror("Error opening file");
                }
                break;
        case 8:
            termCustomerPrize(customers, customerCount); // Pass the array and count
            printf("--------------------------------------------------------------\n");
            break;
        case 9:
            FILE *tempptr= fopen("cloudcustomerdata.txt", "r");
             fclose(tempptr);
             tempptr=fopen("cloudcustomerdata.txt", "w");
             FILE *tempptr2= fopen("modifiedcloudcustomerdata.txt", "r");
             fclose(tempptr2);
             tempptr2=fopen("cloudcustomerdata.txt", "w");
            break;            
        case 10:
            return 0;
        default:
            printf("\nInvalid choice! Please try again.\n");
        }
    }
}
