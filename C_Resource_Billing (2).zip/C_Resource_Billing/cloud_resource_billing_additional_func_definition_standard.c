/** @file Cloud_Resource_Billing_System_Standard.c
*
* @brief
C program to add customer details and to calculate
the total bill for cloud resource usage in minutes,then save the
updated data regarding customer details to a new file.
*
* @par
* COPYRIGHT NOTICE: (c) 2024 Murugesan. All rights reserved.
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

typedef  int uint32_t;
typedef  char uchar1_t;
typedef float float32_t;

/**
 * @brief Trims leading and trailing whitespace from a string.
 *
 * This function removes all leading and trailing whitespace characters from 
 * the provided string. It modifies the string in place.
 *
 * @param str A pointer to the string to be trimmed.
 * @pre The string pointed to by str must be a valid null-terminated C string.
 * @post The string is modified in place to remove leading & trailing whitespace.
 */
void trim_whitespace(uchar1_t *str) 
{

    char *end;

    // Trim leading spaces
    while (isspace((uchar1_t)*str))
    {
      str++;
    } 

    // If all spaces, return
    if (*str == 0)
    {
        return;
    }

    // Trim trailing spaces
    end = str + strlen(str) - 1;

    while (end > str && isspace((uchar1_t)*end))
    {
        end--;
    } 

    // Null-terminate
    *(end + 1) = '\0';
}

/**
 * @brief Generates a random floating-point number within a specified range.
 *
 * This function generates a pseudo-random floating-point number between the 
 * specified minimum and maximum values. The function uses the `rand()` function 
 * to generate a random integer, which is then scaled to a floating-point number 
 * in the range [min, max]. The result is uniformly distributed across range.
 *
 * @param min The minimum value of the range (inclusive).
 * @param max The maximum value of the range (exclusive).
 * @return A random floating-point number between min and max.
 * @pre The `rand()` function is seeded using `srand()` before calling this function.
 * @post The generated number is a pseudo-random floating-point value.
 */
float32_t generate_random_double(float32_t min, float32_t max) 
{
    // Generate a random integer and scale it to the desired range

    float32_t scale = rand() / (float32_t) RAND_MAX;

    return min + scale * (max - min); // Scale to [min, max]
}

/***  end of file  ***/