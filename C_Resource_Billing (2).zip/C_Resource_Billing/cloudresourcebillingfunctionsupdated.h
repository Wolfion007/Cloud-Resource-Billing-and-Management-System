#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include "cloudresourcebillingadditionalfunc.h"

#define MAX_CUSTOMERS 100
#define MAX_MONTHS 10


struct customerdata
{
    char name[50];
    char userId[4];
    float usage;
    float othercomputingresources; // 0.54
    float unitstorage;             // 1.80
    float unitdatabase;            // 0.75
    float totalBill;
};

struct customerdata customers[MAX_CUSTOMERS];
int customerCount = 0;


void termCustomerPrize(struct customerdata *customers, int count) {
    if (count <= 0) {
        printf("No customer records available to reward.\n");
        return;
    }

    // Initialize the pointer to the first customer
    struct customerdata *highestUsageCustomer = &customers[0];

    // Loop through the customers to find the one with the highest usage
    for (int i = 1; i < count; i++) {
        if (customers[i].usage > highestUsageCustomer->usage) {
            highestUsageCustomer = &customers[i];
        }
    }

    // Print the reward message for the customer with the highest usage
    printf("Congratulations to %s for having the highest usage of %.2f minutes! You've been rewarded with bonus star points.\n",
           highestUsageCustomer->name, highestUsageCustomer->usage);
}


void firstandlastuser(FILE *ffptr)
{
    if (!ffptr) {
        perror("Error opening file");
        return;
    }

    char line[256];
    char firstName[50] = "";
    char lastName[50] = "";
    char *token;

    int firstUserFound = 0;

    // Read through the file
    while (fgets(line, sizeof(line), ffptr)) {
        // Tokenize the line to find the name
        token = strtok(line, ":");
        if (token && strcmp(token, "Name") == 0) 
        {
            token = strtok(NULL, "\n");
            if (token) {
                // Trim whitespace from the name
                trim_whitespace(token);

                if (!firstUserFound) {
                    strncpy(firstName, token, sizeof(firstName) - 1);
                    firstName[sizeof(firstName) - 1] = '\0'; // Ensure null-termination
                    firstUserFound = 1;
                }
                // Update the last user name
                strncpy(lastName, token, sizeof(lastName) - 1);
                lastName[sizeof(lastName) - 1] = '\0'; // Ensure null-termination
            }
        }
    }

    
    if (firstUserFound) {
        printf("The First to join, %s!\n", firstName);
    }
    if (*lastName) {
        printf("Welcome Mr/Mrs.%s! who recently tried \n", lastName);
    }

    // Close the file
    fclose(ffptr);

}
extern void addrecord()
{
    FILE *fptr = fopen("cloudcustomerdata.txt", "a+");
    if (!fptr)
    {
        perror("Error opening file");
        return;
    }

    FILE *h_two_fptr = fopen("cloudcustomer_data.csv", "a+");
    if (!h_two_fptr)
    {
        perror("Error opening file");
        return;
    }

    srand((unsigned int) time(NULL));

    if (customerCount < MAX_CUSTOMERS) 
    {
        getchar();
        printf("\nEnter name: ");
        fgets(customers[customerCount].name,50, stdin);
        printf("Enter user_id: ");
        fgets(customers[customerCount].userId, 4, stdin);
        getchar();
        printf("Enter usage (in minutes and length restricted to 4): ");
        scanf("%f", &customers[customerCount].usage);
        
        // Define the range for random values
        float mindat = 0.75;
        float maxdat = 0.85;
        float minsto = 0.89;
        float maxsto = 0.99;
        float mincr = 0.50;
        float maxcr = 0.54;

        // Generate and assign random values
        customers[customerCount].unitdatabase = generate_random_double(mindat, maxdat);
        customers[customerCount].othercomputingresources = generate_random_double(minsto, maxsto);
        customers[customerCount].unitstorage = generate_random_double(mincr, maxcr);

        // Calculate totalBill
        customers[customerCount].totalBill = customers[customerCount].usage *
                                             customers[customerCount].othercomputingresources *
                                             customers[customerCount].unitdatabase *
                                             customers[customerCount].unitstorage;

        // Write to file
        fprintf(fptr,"Record added \n");
        fprintf(fptr,"------------------------------\n");
        fprintf(fptr, "Name: %s\nUserId: %s\nTotalBill: %.2f\nUsage: %.2f\n\n",
                customers[customerCount].name,
                customers[customerCount].userId,
                customers[customerCount].totalBill,
                customers[customerCount].usage);
        fprintf(h_two_fptr,"------------------------------\n");
                fprintf(fptr, "Name: %s\nUserId: %s\nTotalBill: %.2f\nUsage: %.2f\n\n",
                customers[customerCount].name,
                customers[customerCount].userId,
                customers[customerCount].totalBill,
                customers[customerCount].usage);
        fflush(fptr);
        printf("\nRecord added successfully!\n");

        customerCount++;
    }

    else
    {
        printf("\nMaximum number of records reached.\n");
    }
    
    firstandlastuser(fptr);

    fclose(fptr);
    fclose(h_two_fptr);
}

void viewrecords()
{
    printf("\nName\tUserId\tUsage(min)\tTotal Bill($)\n");
    for (int i = 0; i < MAX_CUSTOMERS; i++)
    {
        printf("%s\t%s\t%.2f\t\t%.2f\n", customers[i].name,
               customers[i].userId, customers[i].usage,
               customers[i].totalBill);
    }
}

void modifyRecord(char userId[])
{
    FILE *origFile = fopen("modifiedcloudcustomerdata.txt", "a+");
    if (origFile == NULL)
    {
        perror("Error opening file");
        return;
    }
    int entered = 0;
    if (customerCount < MAX_CUSTOMERS)
    {
        for (int i = 0; i < MAX_CUSTOMERS; i++)
        {
            if (strcmp(customers[i].userId, userId) == 0)
            {
              printf("\nEnter new usage (in minutes) for %s: ", customers[customerCount].name);
              scanf("%f", &customers[customerCount].usage);
              // Define the range for random values
              float mindat = 0.75;
              float maxdat = 0.85;
              float minsto = 0.89;
              float maxsto = 0.99;
              float mincr = 0.50;
              float maxcr = 0.54;

             // Generate and assign random values
             customers[customerCount].unitdatabase = generate_random_double(mindat, maxdat);
             customers[customerCount].othercomputingresources = generate_random_double(minsto, maxsto);
             customers[customerCount].unitstorage = generate_random_double(mincr, maxcr);

              customers[customerCount].totalBill = customers[i].usage * customers[i].othercomputingresources *
              customers[i].unitdatabase * customers[i].unitstorage;
              entered = 1;
              // Write to file
              fprintf(origFile,"Record added \n");
              fprintf(origFile,"------------------------------\n");
              fprintf(origFile, "Name: %s\nUserId: %s\nTotalBill: %.2f\nUsage: %.2f\n\n",
                customers[customerCount].name,
                customers[customerCount].userId,
                customers[customerCount].totalBill,
                 customers[customerCount].usage);
              fprintf(origFile,"------------------------------\n");
              printf("\nRecord added successfully!\n");
              customerCount++;
              break;
            }
        }
            
    }
    if (!entered)
    {
        printf("\nRecord not added!\n");
    }
    fclose(origFile);
}

void viewPayment(char userId[])
{
    int found = 0;
    for (int i = 0; i < MAX_CUSTOMERS; i++)
    {
        if (strcmp(customers[i].userId, userId) == 0)
        {
            printf("\nTotal Bill for %s: $%.2f\n",
                   customers[i].name,
                   customers[i].totalBill);
            found = 1;
            break;
        }
    }
    if (!found)
    {
        printf("\nRecord not found!\n");
    }
}

void searchRecord(char userId[])
{
    int found = 0;
    printf("\nName\tUserId\tUsage(min)\tTotal Bill($)\n");
    for (int i = 0; i < MAX_CUSTOMERS; i++)
    {
        if (strcmp(customers[i].userId, userId) == 0)
        {
            printf("%s\t%s\t%.2f\t\t%.2f\n", customers[i].name, customers[i].userId, customers[i].usage, customers[i].totalBill);
            found = 1;
            break;
        }
    }
    if (!found)
    {
        printf("\nRecord not found!\n");
    }
}

void deleteRecord(char userId[])
{
    for (int i = 0; i < MAX_CUSTOMERS; i++)
    {
        if (strcmp(customers[i].userId, userId) == 0)
        {
            for (int j = i; j < customerCount; j++)
            {
                customers[j] = customers[j + 1];
            }
            printf("\nRecord deleted successfully!\n");
            return;
        }
    }
    customerCount = 0;
    printf("\nRecord not found!\n");
}


