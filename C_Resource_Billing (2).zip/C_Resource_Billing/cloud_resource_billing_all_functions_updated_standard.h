#include <stdio.h>
#include "cloud_resource_billing_all_functions_updated_standard.c"

void add_record();
void initialize_customers();
void cleanup_customers();
void first_and_recent_user(FILE *h_ffptr);
void view_records();
void modify_records(uchar1_t user_id[]);
void view_payment(uchar1_t user_id[]);
void search_records(uchar1_t user_id[]);
void delete_records(uchar1_t user_id[]);
void term_customer_reward(customer_data_t customers[], uint32_t count);
