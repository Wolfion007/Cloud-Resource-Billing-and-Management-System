/** @file Cloud_Resource_Billing_System_Standard.c
*
* @brief
C program to add customer details and to calculate
the total bill for cloud resource usage in minutes,then save the
updated data regarding customer details to a new file.
*
* @par
* COPYRIGHT NOTICE: (c) 2024 Murugesan. All rights reserved.
*/

#include <stdio.h>
#include <string.h>
#include "cloud_resource_billing_all_functions_updated_standard.h"

typedef  int uint32_t;
typedef  char uchar1_t;
typedef float float32_t;

#define MAX_ID_LENGTH 5   //Total length of the user_id

//Function prototype
static inline void display_choices();  

uint32_t main()
{
    uint32_t choice;
    uchar1_t user_id[MAX_ID_LENGTH];
    initialize_customers();
    while (1)
    {  
        display_choices();
        scanf("%d", &choice);
        uint32_t c;
        while ((c = getchar()) != '\n' && c != EOF);
        switch (choice)
        {
        case 1:
            // Add the user details
            add_record();
            printf("-----------------------------------------------\n");
            break;

        case 2:
            // View all users details
            view_records();
            printf("-----------------------------------------------\n");
            break;

        case 3:
            // Modify the user details
            printf("\nEnter user_id to modify record: ");
            fgets(user_id, MAX_ID_LENGTH, stdin);
            modify_records(user_id);
            printf("-----------------------------------------------\n");
            break;

        case 4:
            // The Total payment of user can be calculated
            printf("\nEnter user_id to view payment: ");
            fgets(user_id, MAX_ID_LENGTH, stdin);
            view_payment(user_id);
            printf("-----------------------------------------------\n");
            break;

        case 5:
            // Search the user record
            printf("\nEnter user_id to search record: ");
            fgets(user_id, MAX_ID_LENGTH, stdin);
            search_records(user_id);
            printf("-----------------------------------------------\n");
            break;

        case 6:
            // Delete the user record
            printf("\nEnter user_id to delete record: ");
            fgets(user_id, MAX_ID_LENGTH, stdin);
            delete_records(user_id);
            printf("-----------------------------------------------\n");
            break;

        case 7:
            FILE *h_ffptr = fopen("cloudcustomer_data.txt", "r");
                if (h_ffptr) 
                {
                    printf("\nThe First and the Most Recent user is:\n");
                    printf("-------------------------------------------\n");
                    first_and_recent_user(h_ffptr);
                    fclose(h_ffptr);
                }

                else 
                {
                    perror("Error opening file");
                }
                break;

        case 8:
            term_customer_reward(customers, g_customer_count); // Pass the array and count
            printf("-------------------------------------------\n");
            break;

        case 9:
            FILE *h_temp_ptr= fopen("cloudcustomer_data.txt", "r");
            fclose(h_temp_ptr);
            h_temp_ptr=fopen("cloudcustomer_data.txt", "w");
            FILE *h_temp_ptr_2= fopen("modifiedcloudcustomer_data.txt", "r");
            fclose(h_temp_ptr_2);
            h_temp_ptr_2=fopen("cloudcustomer_data.txt", "w");
            printf("Status Updated\a\t Record Cleared\n");
            break;          

        case 10:
            return 0;

        default:
            printf("\nInvalid choice! Please try again.\n");
        }
      

    }
 
}
/**
 * @brief Displays the menu choices to the user.
 *
 * This function prints out the options available in the menu for the user
 * to select from. It does not modify any global state.
 *
 * @pre The function only prints to the console and does not interact with files.
 * @post The menu options are displayed to the user.
 */

static inline void display_choices()
{   
    printf("\nInstructions to be followed\n");
    printf("1.Name should be valid and 20 characters are only allowed\n");
    printf("2.UserId should be valid and 4 characters are only allowed\n\n");
    printf("\n--- Customer Records Menu ---\n");
    printf("1. Add Record\n");
    printf("2. View Records\n");
    printf("3. Modify Record\n");
    printf("4. View Payment\n");
    printf("5. Search Record\n");
    printf("6. Delete Record\n");
    printf("7. Finding First and Recent Customer\n");
    printf("8. Rewarding the user with Highest Usage\n");
    printf("9. Erasing all customer data from the database\n");
    printf("10. Exit\n");
    printf("Enter your choice: ");
}


/** end of file **/