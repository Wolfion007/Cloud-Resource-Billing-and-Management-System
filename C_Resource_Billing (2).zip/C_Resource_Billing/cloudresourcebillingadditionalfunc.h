#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

void trim_whitespace(char *str) {
    char *end;

    // Trim leading spaces
    while (isspace((unsigned char)*str)) str++;

    // If all spaces, return
    if (*str == 0)
        return;

    // Trim trailing spaces
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;

    // Null-terminate
    *(end + 1) = '\0';
}

void openFile(const char *filename) {
    char command[256];

    snprintf(command, sizeof(command), "notepad \"%s\"", filename); // Quotes to handle filenames with spaces

    int result = system(command);

    if (result != 0) {
        printf("Failed to open file in Notepad. System call returned %d\n", result);
    }
}

float generate_random_double(float min, float max) 
{
    // Generate a random integer and scale it to the desired range

    float scale = rand() / (float) RAND_MAX;

    return min + scale * (max - min); // Scale to [min, max]
}