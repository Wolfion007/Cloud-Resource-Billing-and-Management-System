#include <stdio.h>
#include "cloud_resource_billing_additional_func_definition_standard.c"

typedef int uint32_t;
typedef char uchar1_t;
typedef float float32_t;

void trim_whitespace(uchar1_t *str);
float32_t generate_random_double(float32_t min, float32_t max);